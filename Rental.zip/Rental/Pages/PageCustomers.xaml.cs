﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Rental.Classes;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;


namespace Rental.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageCustomers.xaml
    /// </summary>
    public partial class PageCustomers : Page
    {
        public PageCustomers()
        {
            InitializeComponent();
            dtgCusts.ItemsSource = VideoRentalEntities.GetContext().Customers.ToList();
        }

        private void MenuAdd_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new ADDPageCustomers(null));
        }

        private void MenuEdit_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new ADDPageCustomers((Customers)dtgCusts.SelectedItem));
        }

        private void MenuUpdate_Click(object sender, RoutedEventArgs e)
        {
            dtgCusts.ItemsSource = VideoRentalEntities.GetContext().Customers.ToList();
        }

        private void MenuDel_Click(object sender, RoutedEventArgs e)
        {
            var salesForRemoving = dtgCusts.SelectedItems.Cast<Customers>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {salesForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    VideoRentalEntities.GetContext().Customers.RemoveRange(salesForRemoving);
                    VideoRentalEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    dtgCusts.ItemsSource = VideoRentalEntities.GetContext().Customers.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void MenuSaveToExcel_Click(object sender, RoutedEventArgs e)
        {
            Excel.Application excelApp = new Excel.Application();
            Excel.Workbook wb = excelApp.Workbooks.Open($"{Directory.GetCurrentDirectory()}\\Шаблон.xlsx");
            Excel.Worksheet ws = (Excel.Worksheet)wb.Worksheets[1];
            ws.Cells[2][2] = "Клиенты";
            ws.Cells[4, 3] = DateTime.Now.ToString();
            ws.Cells[4, 6] = 7;
            int indexRows = 5;
            ws.Cells[1][indexRows + 1] = "Номер";
            ws.Cells[2][indexRows + 1] = "ФИО";
            ws.Cells[3][indexRows + 1] = "Паспорт";
            ws.Cells[4][indexRows + 1] = "Телефон";
            var printItems = dtgCusts.Items;
            foreach (Customers item in printItems)
            {
                ws.Cells[1][indexRows + 1] = indexRows;
                ws.Cells[2][indexRows + 1] = item.fio;
                ws.Cells[3][indexRows + 1] = item.passport;
                ws.Cells[4][indexRows + 1] = item.telephone;
                indexRows++;
            }
            ws.Cells[indexRows + 2, 3] = "Подпись";
            ws.Cells[indexRows + 2, 5] = "Мальчик А.В.";
            excelApp.Visible = true;
        }
    }
}