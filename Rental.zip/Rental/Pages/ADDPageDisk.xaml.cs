﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Rental.Classes;

namespace Rental.Pages

{
    /// <summary>
    /// Логика взаимодействия для ADDPageDisk.xaml
    /// </summary>
    public partial class ADDPageDisk : Page
    {
        private Disk _currentItem = new Disk();
        public ADDPageDisk(Disk selectedItem)
        {
            InitializeComponent();
            if (selectedItem != null)
            {
                _currentItem = selectedItem;
                Titletxt.Text = "Изменение диска";
                BtnAdd.Content = "Изменить";
            }
            // Создаём контекст
            DataContext = _currentItem;
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();

            if (string.IsNullOrWhiteSpace(_currentItem.title)) error.AppendLine("Укажите название");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentItem.genre))) error.AppendLine("Укажите жанр");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentItem.duration))) error.AppendLine("Укажите продолжительность(мин.)");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentItem.Cost_per_day))) error.AppendLine("Укажите стоимость за день");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentItem.IdDisk == 0)
            {
                VideoRentalEntities.GetContext().Disk.Add(_currentItem);
                try
                {
                    VideoRentalEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageDisk());
                    MessageBox.Show("Новый диск успешно добавлен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    VideoRentalEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageDisk());
                    MessageBox.Show("Диск успешно изменён!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageDisk());
        }
    }
}
