﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Rental.Classes;

namespace Rental.Pages
{
    /// <summary>
    /// Логика взаимодействия для ADDPageCustomers.xaml
    /// </summary>
    public partial class ADDPageCustomers : Page
    {
        private Customers _currentItem = new Customers();
        public ADDPageCustomers(Customers selectedItem)
        {
            InitializeComponent();
            if (selectedItem != null)
            {
                _currentItem = selectedItem;
                Titletxt.Text = "Изменение клиента";
                BtnAdd.Content = "Изменить";
            }
            // Создаём контекст
            DataContext = _currentItem;
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();

            if (string.IsNullOrWhiteSpace(_currentItem.fio)) error.AppendLine("Укажите ФИО");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentItem.passport))) error.AppendLine("Укажите паспортные данные");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentItem.telephone))) error.AppendLine("Укажите телефон");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentItem.IdCustomers == 0)
            {
                VideoRentalEntities.GetContext().Customers.Add(_currentItem);
                try
                {
                    VideoRentalEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageCustomers());
                    MessageBox.Show("Новый клиент успешно добавлен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    VideoRentalEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageCustomers());
                    MessageBox.Show("Клиент успешно изменён!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageCustomers());
        }
    }
}
