﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Rental.Classes;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;


namespace Rental.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageDisk.xaml
    /// </summary>
    public partial class PageDisk : Page
    {
        public PageDisk()
        {
            InitializeComponent();
            dtgDisk.ItemsSource = VideoRentalEntities.GetContext().Disk.ToList();
        }

        private void MenuAdd_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new ADDPageDisk(null));
        }

        private void MenuEdit_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new ADDPageDisk((Disk)dtgDisk.SelectedItem));
        }

        private void MenuUpdate_Click(object sender, RoutedEventArgs e)
        {
            dtgDisk.ItemsSource = VideoRentalEntities.GetContext().Disk.ToList();
        }

        private void MenuFilterDisk1_Click(object sender, RoutedEventArgs e)
        {
            dtgDisk.ItemsSource = VideoRentalEntities.GetContext().Disk.Where(x => x.Cost_per_day <= 500).ToList();
        }

        private void MenuFilterDisk2_Click(object sender, RoutedEventArgs e)
        {
            dtgDisk.ItemsSource = VideoRentalEntities.GetContext().Disk.Where(x => x.Cost_per_day >= 501 && x.Cost_per_day <= 1500).ToList();
        }

        private void MenuFilterDisk3_Click(object sender, RoutedEventArgs e)
        {
            dtgDisk.ItemsSource = VideoRentalEntities.GetContext().Disk.Where(x => x.Cost_per_day >= 1501).ToList();
        }

        private void MenuSortFiltСlear_Click(object sender, RoutedEventArgs e)
        {
            dtgDisk.ItemsSource = VideoRentalEntities.GetContext().Disk.ToList();
        }
        private void MenuFilterDisk4_Click(object sender, RoutedEventArgs e)
        {
            dtgDisk.ItemsSource = VideoRentalEntities.GetContext().Disk.Where(x => x.duration <= 50).ToList();
        }

        private void MenuFilterDisk5_Click(object sender, RoutedEventArgs e)
        {
            dtgDisk.ItemsSource = VideoRentalEntities.GetContext().Disk.Where(x => x.duration >= 51 && x.duration <= 150).ToList();
        }

        private void MenuFilterDisk6_Click(object sender, RoutedEventArgs e)
        {
            dtgDisk.ItemsSource = VideoRentalEntities.GetContext().Disk.Where(x => x.duration >= 151).ToList();
        }

        private void MenuDel_Click(object sender, RoutedEventArgs e)
        {
            var salesForRemoving = dtgDisk.SelectedItems.Cast<Disk>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {salesForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    VideoRentalEntities.GetContext().Disk.RemoveRange(salesForRemoving);
                    VideoRentalEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    dtgDisk.ItemsSource = VideoRentalEntities.GetContext().Disk.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void MenuSaveToExcel_Click(object sender, RoutedEventArgs e)
        {
            Excel.Application excelApp = new Excel.Application();
            Excel.Workbook wb = excelApp.Workbooks.Open($"{Directory.GetCurrentDirectory()}\\Шаблон.xlsx");
            Excel.Worksheet ws = (Excel.Worksheet)wb.Worksheets[1];
            ws.Cells[2][2] = "Диски";
            ws.Cells[4, 3] = DateTime.Now.ToString();
            ws.Cells[4, 6] = 7;
            int indexRows = 5;
            ws.Cells[1][indexRows + 1] = "Номер";
            ws.Cells[2][indexRows + 1] = "Название";
            ws.Cells[3][indexRows + 1] = "Жанр";
            ws.Cells[4][indexRows + 1] = "Продолжительность в мин";
            ws.Cells[5][indexRows + 1] = "Стоимость за день";
            var printItems = dtgDisk.Items;
            foreach (Disk item in printItems)
            {
                ws.Cells[1][indexRows + 1] = indexRows;
                ws.Cells[2][indexRows + 1] = item.title;
                ws.Cells[3][indexRows + 1] = item.genre;
                ws.Cells[4][indexRows + 1] = item.duration;
                ws.Cells[5][indexRows + 1] = item.Cost_per_day;
                indexRows++;
            }
            ws.Cells[indexRows + 2, 3] = "Подпись";
            ws.Cells[indexRows + 2, 5] = "Мальчик А.В.";
            excelApp.Visible = true;
        }
    }
}
