﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Rental.Classes;

namespace Rental.Pages
{
    /// <summary>
    /// Логика взаимодействия для ADDPageRent.xaml
    /// </summary>
    public partial class ADDPageRent : Page
    {
        private Rent _currentItem = new Rent();
        public ADDPageRent(Rent selectedItem)
        {
            InitializeComponent();
            InitializeComponent();
            if (selectedItem != null)
            {
                _currentItem = selectedItem;
                Titletxt.Text = "Изменение аренды";
                BtnAdd.Content = "Изменить";
            }
            // Создаём контекст
            DataContext = _currentItem;
            CmbIdCustomers.ItemsSource = VideoRentalEntities.GetContext().Customers.ToList();
            CmbIdCustomers.SelectedValuePath = "IdCustomers";
            CmbIdCustomers.DisplayMemberPath = "fio";
            CmbIdDisk.ItemsSource = VideoRentalEntities.GetContext().Disk.ToList();
            CmbIdDisk.SelectedValuePath = "IdDisk";
            CmbIdDisk.DisplayMemberPath = "title";
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();

            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentItem.rental_date))) error.AppendLine("Укажите дату взятия");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentItem.return_date))) error.AppendLine("Укажите дату возврата");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentItem.returned))) error.AppendLine("Укажите вернул или нет");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentItem.IdCustomers))) error.AppendLine("Укажите клиента");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentItem.IdDisk))) error.AppendLine("Укажите диск");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentItem.IdRent == 0)
            {
                VideoRentalEntities.GetContext().Rent.Add(_currentItem);
                try
                {
                    VideoRentalEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageRent());
                    MessageBox.Show("Новая аренда успешно добавлена!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    VideoRentalEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageRent());
                    MessageBox.Show("Аренда успешно изменёна!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageRent());
        }
    }       
}
