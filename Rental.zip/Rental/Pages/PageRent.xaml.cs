﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Rental.Classes;
using Excel = Microsoft.Office.Interop.Excel;

namespace Rental.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageRent.xaml
    /// </summary>
    public partial class PageRent : Page
    {
        public PageRent()
        {
            InitializeComponent();
            dtgRent.ItemsSource = VideoRentalEntities.GetContext().Rent.ToList();
        }

        private void MenuAdd_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new ADDPageRent(null));
        }

        private void MenuEdit_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new ADDPageRent((Rent)dtgRent.SelectedItem));
        }

        private void MenuUpdate_Click(object sender, RoutedEventArgs e)
        {
            dtgRent.ItemsSource = VideoRentalEntities.GetContext().Customers.ToList();
        }


        private void TxbSearchClient_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (dtgRent.ItemsSource != null)
                dtgRent.ItemsSource = VideoRentalEntities.GetContext().Rent.Where(x => x.Customers.fio.ToLower().Contains(TxbSearchClient.Text.ToLower())).ToList();
            if (TxbSearchClient.Text.Count() == 0) dtgRent.ItemsSource = VideoRentalEntities.GetContext().Rent.ToList();
        }

        private void MenuDel_Click(object sender, RoutedEventArgs e)
        {
            var salesForRemoving = dtgRent.SelectedItems.Cast<Rent>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {salesForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    VideoRentalEntities.GetContext().Rent.RemoveRange(salesForRemoving);
                    VideoRentalEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    dtgRent.ItemsSource = VideoRentalEntities.GetContext().Rent.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void MenuSaveToExcel_Click(object sender, RoutedEventArgs e)
        {
            Excel.Application excelApp = new Excel.Application();
            Excel.Workbook wb = excelApp.Workbooks.Open($"{Directory.GetCurrentDirectory()}\\Шаблон.xlsx");
            Excel.Worksheet ws = (Excel.Worksheet)wb.Worksheets[1];
            ws.Cells[2][2] = "Аренда";
            ws.Cells[4, 3] = DateTime.Now.ToString();
            ws.Cells[4, 6] = 7;
            int indexRows = 5;
            ws.Cells[1][indexRows + 1] = "Номер";
            ws.Cells[2][indexRows + 1] = "Дата взятия";
            ws.Cells[3][indexRows + 1] = "Дата возврата";
            ws.Cells[4][indexRows + 1] = "Вернул или нет";
            ws.Cells[5][indexRows + 1] = "ФИО клиента";
            ws.Cells[6][indexRows + 1] = "Название диска";
            var printItems = dtgRent.Items;
            foreach (Rent item in printItems)
            {
                ws.Cells[1][indexRows + 1] = indexRows;
                ws.Cells[2][indexRows + 1] = item.rental_date;
                ws.Cells[3][indexRows + 1] = item.return_date;
                ws.Cells[4][indexRows + 1] = item.returned;
                ws.Cells[5][indexRows + 1] = item.Customers.fio;
                ws.Cells[6][indexRows + 1] = item.Disk.title;
                indexRows++;
            }
            ws.Cells[indexRows + 2, 3] = "Подпись";
            ws.Cells[indexRows + 2, 5] = "Мальчик А.В.";
            excelApp.Visible = true;
        }
    }
}
